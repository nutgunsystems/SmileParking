class MyConstant {
  //For access via DNS
  ///Internal Link for localhost
  //String domain_url = 'http://192.168.64.2';

  //External Link mapping via ngrok for real mobile device connection
  String domain_url = 'http://3ef174e73e77.ngrok.io';

  MyConstant();
}
