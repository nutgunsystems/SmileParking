package com.flutterthailand.smileparking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
